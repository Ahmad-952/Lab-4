class Student {
    constructor(name, marks) {
        this.name = name;
        this.marks = marks;
    }

    getGrade() {
        if (this.marks >= 80) {
            return "A";
        } else if (this.marks >= 70) {
            return "B";
        } else if (this.marks >= 50) {
            return "C";
        } else {
            return "F";
        }
    }
}

// Student objects
const students = [
    new Student("Ali", 85),
    new Student("Sara", 72),
    new Student("Ahmed", 91),
    new Student("Ayesha", 64),
    new Student("Usman", 45),
    new Student("Fatima", 78)
];

// Passing students: filter + map
const passingNames = students
    .filter(student => student.marks >= 50)
    .map(student => student.name);

// Class average: reduce
const totalMarks = students.reduce(
    (total, student) => total + student.marks,
    0
);

const classAverage = totalMarks / students.length;

// Top scorer: sort + destructuring
const sortedStudents = [...students].sort(
    (a, b) => b.marks - a.marks
);

const [topScorer] = sortedStudents;

// Get HTML element
const output = document.getElementById("output");

// Display students
output.innerHTML = "<h2>All Students</h2>";

students.forEach(student => {

    // Ternary operator
    const status = student.marks >= 50 ? "Pass" : "Fail";

    output.innerHTML += `
        <p>
            <strong>${student.name}</strong>
            | Marks: ${student.marks}
            | Grade: ${student.getGrade()}
            | <strong>${status}</strong>
        </p>
    `;
});

// Passing names
output.innerHTML += `
    <h2>Passing Names</h2>
    <p>${passingNames.join(", ")}</p>
`;

// Class average
output.innerHTML += `
    <h2>Class Average</h2>
    <p>${classAverage.toFixed(2)}</p>
`;

// Top scorer
output.innerHTML += `
    <h2>Top Scorer</h2>
    <p>${topScorer.name} - ${topScorer.marks} marks</p>
`;

// Console output as well
console.log("Passing Names:", passingNames);
console.log("Class Average:", classAverage.toFixed(2));
console.log("Top Scorer:", topScorer.name);
